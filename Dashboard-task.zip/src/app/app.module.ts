import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LeftNavigationComponent } from './left-navigation/left-navigation.component';
import { RightContainerComponent } from './right-container/right-container.component';
import { FusionChartsModule } from 'angular-fusioncharts';
import * as FusionCharts from 'fusioncharts';
import * as Charts from 'fusioncharts/fusioncharts.charts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import { TableModule } from 'primeng/table';
import {CardModule} from 'primeng/card';
import { CheckboxModule } from 'primeng/checkbox';
import { AvatarModule } from 'primeng/avatar';
import { AvatarGroupModule } from 'primeng/avatargroup';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule  } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { PaginatorModule } from 'primeng/paginator';
import { NgCircleProgressModule } from 'ng-circle-progress';

FusionChartsModule.fcRoot(
  FusionCharts,
  Charts,
  FusionTheme
)
@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LeftNavigationComponent,
    RightContainerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FusionChartsModule,
    HttpClientModule,
    TableModule,
    CardModule,
    CheckboxModule,
    AvatarModule,
    AvatarGroupModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    ButtonModule,
    ToastModule,
    PaginatorModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: "#78C000",
      innerStrokeColor: "#C7E596",
      animationDuration: 300,
    })
 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
