import { TestBed } from '@angular/core/testing';

import { RighContainerService } from './righ-container.service';

describe('RighContainerService', () => {
  let service: RighContainerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RighContainerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
