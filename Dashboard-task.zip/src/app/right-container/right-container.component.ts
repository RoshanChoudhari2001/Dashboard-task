import { Component, OnInit } from '@angular/core';
import { RighContainerService } from './righ-container.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
// import Highcharts from 'highcharts/es-modules/masters/highcharts.src';
import * as Highcharts from 'highcharts';

declare var $: any;
@Component({
  selector: 'app-right-container',
  templateUrl: './right-container.component.html',
  styleUrls: ['./right-container.component.css'],
  providers: [MessageService]
})
export class RightContainerComponent implements OnInit {
  Highcharts: any = Highcharts;
  dataSource:any;
  dataSource2:any;
  type = "doughnut2d";
  dataFormat = "json";
  gridData :any;
  gridColumns:any;
  dynamicColumns  :any;
  checkedData:any ;
  editForm !:FormGroup;
  progress: number = 75; // Set your desired progress percentage
  outerColor: string = '#78C000'; // Set outer stroke color
  innerColor: string = '#C7E596'
 
  constructor(private RighContainerService:RighContainerService ,private messageService: MessageService) { }

  ngOnInit(): void {
  this.getData();
  this.editForm = new FormGroup({
    firstname : new FormControl('', ),
    lastname :new FormControl('', ),
    role : new FormControl('', )
  });
    this.dataSource = {
      "chart": {
          "xAxisName": "Months",
          "yAxisName": "Security Rating",
          "theme": "fusion"
      },
      "data": [{
          "label": "Jan",
          "value": "25"
      }, {
          "label": "Feb",
          "value": "35"
      }, {
          "label": "Mar",
          "value": "20"
      }, {
          "label": "Apr",
          "value": "20"
      }, {
          "label": "May",
          "value": "25"
      }, {
          "label": "Jun",
          "value": "27"
      }, {
          "label": "Jul",
          "value": "29"
      }, {
          "label": "Aug",
          "value": "24"
      },
      {
        "label": "nov",
        "value": "23"
    },
    {
      "label": "Dec",
      "value": "21"
  }]
  };
 

}
  
getData(){
  
     this.RighContainerService.fetchgridata().subscribe((res:any)=>{
           this.gridColumns =res.grid_columns ;
           this.gridData  = res.grid_data ;
      this.dynamicColumns = res.grid_columns.map((column:any)=> ({
        column_key : column.column_key,
        column_name: column.column_name,
      }));
         console.log(res);
        
     })

}

  editdata(Data :any){
       
    console.log(Data.name);
    
    $('#editmodal').modal('show');
    this.editForm.patchValue({
      firstname :Data.name.first_name,
      lastname :Data.name.last_name,
      role : Data.role
    });
  }


  deleteItem(item :any) {
   console.log(item);
   
     const index = this.gridData.findIndex((dataItem :any) => dataItem.id === item.id);
    if (index !== -1) {
      this.gridData.splice(index, 1);
      this.messageService.add({ severity: 'success', summary: 'Success', detail: 'User Deleted Temporary' });
    }
  }
}
