import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class RighContainerService {

  constructor(private http :HttpClient) { }

  fetchgridata(){
    return this.http.get('https://1.api.fy23ey04.careers.ifelsecloud.com/');
  }
}
